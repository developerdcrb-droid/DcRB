# setup.py
from setuptools import setup, find_packages

setup(
    name="dcrb",
    version="4.1.1",
    description="Discord Remote Bot\n免責聲明：本程式工具僅供用於您有權完全使用之電腦，使用者應為自身一切操作負完全之責任。使用即代表同意。",
    packages=find_packages(),
    package_data={
        "dcrb": ["dcrb.exe"],
    },
    include_package_data=True,
    entry_points={
        "console_scripts": [
            "dcrb = dcrb.launcher:main",
        ],
    },
    classifiers=[],
)
